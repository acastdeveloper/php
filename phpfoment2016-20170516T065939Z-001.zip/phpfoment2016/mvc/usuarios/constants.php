<?php
	const MODULO = 'usuarios/';
	# controladores
	const SET_USER = 'set';
	const GET_USER = 'get';
	const GET_ALL_USER = 'listar';
	const DELETE_USER = 'delete';
	const EDIT_USER = 'edit';

	# vistas
	const VIEW_SET_USER = 'agregar';
	const VIEW_GET_USER = 'buscar';
	const VIEW_DELETE_USER = 'borrar';
	const VIEW_EDIT_USER = 'modificar';
	const VIEW_ALL_USER = 'listar';
?>