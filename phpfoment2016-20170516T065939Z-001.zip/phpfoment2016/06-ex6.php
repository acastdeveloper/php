<?php
echo str_ireplace("WORld", "Dolly", "Hello world!"); 
// outputs Hello Dolly!
?>