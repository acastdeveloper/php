<!DOCTYPE html>
<html>
<body>
<?php
$t = 1;
if ($t > 17): ?>
    Eres mayor de edad<br>
<?php else: ?>
	Eres menor de edad<br>
<?php endif ?>
Esto se ve siempre
</body>
</html>