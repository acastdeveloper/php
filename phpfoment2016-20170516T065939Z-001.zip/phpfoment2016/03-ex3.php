<!DOCTYPE html>
<html>
<body>

<?php
$x = 5;
$y = 4;
$texto = "Hola son las ";
echo "Hola son las " . ($x + $y)."<br>";
echo $texto . ($x + $y);
?>

</body>
</html>