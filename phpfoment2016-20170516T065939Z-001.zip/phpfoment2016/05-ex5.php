<!DOCTYPE html>
<html>
<body>

<?php
echo stripos("Hello World! world", "WORLD");
?> 
 
</body>
</html>