<!DOCTYPE html>
<html>
<body>
<?php
$t = 18;
if ($t > 17) {
    echo "Eres mayor de edad<br>";
}
else{
	echo "Eres menor de edad<br>";
}
echo "Esto se ve siempre";
?>
</body>
</html>