<?php

require 'vendor/autoload.php'; 
	
echo "hola mundo";
?>