<?php
interface Postre {
 public function set_ingredientes();
}
