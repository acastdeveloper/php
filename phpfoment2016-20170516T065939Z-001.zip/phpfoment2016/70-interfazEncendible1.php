<?php

interface Encendible{ 
    const foo = 'bar';
   	public function encender(); 
   	public function apagar(); 
}
?>