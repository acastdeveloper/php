<?php
 $cuadrado = array(
 	array(0, 0), 
 	array(10, 0),
 	array(10, 10),
 	array(0, 10)
 );
 print_r($cuadrado);
?>