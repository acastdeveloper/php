<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<body>

<form action="26-forms1b.php" method="POST" class="w3-container w3-card-4 w3-light-grey">
<h3>Formulario:</h3>
<p>
<label>Nombre</label>
<input class="w3-input" type="text" name="nombre"></p>
<label>Apellido</label>
<input class="w3-input" type="text" name="apellido"></p>
<input class="w3-radio" type="radio" name="genero" value="hombre" >
<label class="w3-validate">Hombre</label>

<input class="w3-radio" type="radio" name="genero" value="mujer" >
<label class="w3-validate">Mujer</label>
<input type="submit" name="">
</form>
<br>

</body>
</html>

