<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		echo readfile("include/webdictionary.txt");
	?>
</body>
</html>