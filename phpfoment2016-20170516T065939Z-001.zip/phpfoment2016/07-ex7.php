<!DOCTYPE html>
<html>
<body>

<?php
$str = "Hello world. It's a beautiful day.";
$arr = explode(" ",$str);
echo($arr[0]);
?> 

</body>
</html>