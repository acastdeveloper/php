<?php
$t = 0;

if ($t < 0) {
    echo "Es negativo";
} elseif ($t == 0) {
    echo "Es cero";
} else {
    echo "Es positivo";
}
?>