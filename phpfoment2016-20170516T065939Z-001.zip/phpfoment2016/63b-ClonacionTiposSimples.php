<?php
	$a = 4;
	$b = $a;
	$b++;
	echo "El valor de a es ".$a."<br>";
	echo "El valor de b es ".$b;
?>