<?php 
	phpinfo();
?>