<?php

	require '70-InterfazBombilla.php';
	require '70-interfazCoche.php';

	$bombilla = new Bombilla();
	$coche = new Coche();
?>