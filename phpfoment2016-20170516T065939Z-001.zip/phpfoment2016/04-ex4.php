<?php
echo "<h2>PHP is Fun!</h2>";
echo("<br>".print "I'm about to learn PHP!");
$x = print "I'm about to learn PHP!";
$y = 2;
echo $x;
?>